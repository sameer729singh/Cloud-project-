# Deploy Stock Alerts Core to Render

This repository is prepared to run as a small Node.js HTTP service on Render.

## Deploy

1. Extract this ZIP on your computer.
2. Upload the *contents* of `stock-alerts-core` to a new GitHub repository (the `package.json`, `src/`, and `render.yaml` should be at the repository root).
3. In Render, choose **New + → Blueprint** and connect that GitHub repository. Render will read `render.yaml`.
   - Alternatively choose **New + → Web Service**, use the repository root, set **Build Command** to `npm install`, **Start Command** to `npm start`, and **Health Check Path** to `/health`.
4. Deploy. Open the URL Render gives you, then visit `/health` and `/api/info`.

## What is deployed right now

- `GET /health`: checks whether the service is running.
- `GET /api/info`: describes current API capabilities and limitations.
- The existing TypeScript alert engine and tests remain in `src/` and `tests/`.

## Important limitations

This is a backend deployment starter, not a finished stock-alert product. It does **not** yet expose alert CRUD endpoints, authenticate users, persist data in Postgres, send notifications, or connect to a real NSE/BSE market-data provider. Do not rely on it for live prices or trading decisions. The engine's in-memory store is not durable across restarts.

## Local run

```sh
npm install
npm start
```

Then open `http://localhost:10000/health`.
