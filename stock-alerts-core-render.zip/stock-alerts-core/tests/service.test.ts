import test from 'node:test';
import assert from 'node:assert/strict';
import { setup } from './helpers';
import { NotFoundError, ValidationError, LimitError, MAX_ALERTS_PER_USER } from '../src/alerts/service';
import { WatchlistService } from '../src/watchlists';

test('another user cannot read, edit, pause or delete my alert', async () => {
  const s = setup();
  const a = await s.create('owner');
  await assert.rejects(() => s.alerts.get('attacker', a.id), NotFoundError);
  await assert.rejects(() => s.alerts.update('attacker', a.id, { targetPrice: 1 }), NotFoundError);
  await assert.rejects(() => s.alerts.update('attacker', a.id, { isEnabled: false }), NotFoundError);
  await assert.rejects(() => s.alerts.delete('attacker', a.id), NotFoundError);
  assert.equal((await s.alerts.get('owner', a.id)).targetPrice, 1400, 'unchanged');
  assert.deepEqual(await s.alerts.list('attacker'), []);
});

test('foreign id and missing id are indistinguishable', async () => {
  const s = setup();
  const a = await s.create('owner');
  const e1 = await s.alerts.get('attacker', a.id).catch(e => e);
  const e2 = await s.alerts.get('attacker', 'does-not-exist').catch(e => e);
  assert.equal(e1.message, e2.message);
});

test('mass assignment: callers cannot change owner or engine state', async () => {
  const s = setup();
  const a = await s.create('owner');
  await s.alerts.update('owner', a.id, { userId: 'attacker', armed: false, lastObservedPrice: 5 } as any);
  const after = await s.alerts.get('owner', a.id);
  assert.equal(after.userId, 'owner');
  assert.equal(after.armed, true);
  assert.equal(after.lastObservedPrice, null);
});

test('input validation', async () => {
  const s = setup();
  await assert.rejects(() => s.create('u', { targetPrice: -5 }), ValidationError);
  await assert.rejects(() => s.create('u', { targetPrice: NaN }), ValidationError);
  await assert.rejects(() => s.create('u', { symbol: "RELIANCE'; DROP TABLE" }), ValidationError);
  await assert.rejects(() => s.create('u', { exchange: 'NYSE' as any }), ValidationError);
  await assert.rejects(() => s.create('u', { condition: 'MOON' as any }), ValidationError);
  await assert.rejects(() => s.create('u', { expiresAt: new Date(s.clock.t.getTime() - 1000) }), ValidationError);
});

test('per-user alert limit', async () => {
  const s = setup();
  for (let i = 0; i < MAX_ALERTS_PER_USER; i++) await s.create('u', { targetPrice: 100 + i });
  await assert.rejects(() => s.create('u'), LimitError);
  await s.create('someone-else'); // other users unaffected
});

test('pause / resume / edit; same stock can have several targets', async () => {
  const s = setup();
  const a = await s.create('u', { targetPrice: 1400 });
  await s.create('u', { targetPrice: 1300 });
  assert.equal((await s.alerts.list('u')).length, 2);
  await s.alerts.update('u', a.id, { isEnabled: false });
  assert.equal((await s.store.listActiveAlerts(s.clock.now())).length, 1);
  await s.alerts.update('u', a.id, { isEnabled: true, targetPrice: 1350 });
  assert.equal((await s.store.listActiveAlerts(s.clock.now())).length, 2);
});

test('resuming forgets the old previous price so no fake crossing fires', async () => {
  const s = setup();
  const a = await s.create('u', { condition: 'CROSSES_ABOVE', targetPrice: 1400 });
  await s.tick(1390);                                   // previous = 1390
  await s.alerts.update('u', a.id, { isEnabled: false });
  await s.alerts.update('u', a.id, { isEnabled: true });
  assert.equal((await s.tick(1500)).triggered.length, 0); // 1500 is first observation after resume
  assert.equal((await s.alerts.get('u', a.id)).lastObservedPrice, 1500);
});

test('watchlists are private per user', async () => {
  const s = setup();
  const w = new WatchlistService(s.store, s.clock.now);
  const mine = await w.create('alice', 'Banks');
  await w.create('bob', 'Banks');
  await w.addStock('alice', mine.id, 'HDFCBANK', 'NSE');
  await w.addStock('alice', mine.id, 'HDFCBANK', 'NSE'); // duplicate ignored
  assert.equal((await w.list('alice'))[0]!.stocks.length, 1);
  assert.equal((await w.list('bob'))[0]!.stocks.length, 0);
  await assert.rejects(() => w.addStock('bob', mine.id, 'TCS', 'NSE'), NotFoundError);
  await assert.rejects(() => w.removeStock('bob', mine.id, 'HDFCBANK', 'NSE'), NotFoundError);
  await assert.rejects(() => w.delete('bob', mine.id), NotFoundError);
  assert.equal((await w.list('alice')).length, 1);
});
