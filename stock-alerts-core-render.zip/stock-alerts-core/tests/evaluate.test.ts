import test from 'node:test';
import assert from 'node:assert/strict';
import { evaluate } from '../src/alerts/evaluate';

test('ABOVE / BELOW are strict', () => {
  assert.equal(evaluate('ABOVE', 1400, null, 1400.01), true);
  assert.equal(evaluate('ABOVE', 1400, null, 1400), false);
  assert.equal(evaluate('BELOW', 1400, null, 1399.99), true);
  assert.equal(evaluate('BELOW', 1400, null, 1400), false);
});

test('REACHES: exact match, or jumping across the target', () => {
  assert.equal(evaluate('REACHES', 1400, 1390, 1400), true);
  assert.equal(evaluate('REACHES', 1400, null, 1400), true);
  assert.equal(evaluate('REACHES', 1400, 1390, 1410), true);
  assert.equal(evaluate('REACHES', 1400, 1410, 1390), true);
  assert.equal(evaluate('REACHES', 1400, 1390, 1395), false);
});

test('crossing needs a previous price and a real transition', () => {
  assert.equal(evaluate('CROSSES_ABOVE', 1400, null, 1500), false);
  assert.equal(evaluate('CROSSES_ABOVE', 1400, 1399, 1401), true);
  assert.equal(evaluate('CROSSES_ABOVE', 1400, 1401, 1402), false);
  assert.equal(evaluate('CROSSES_ABOVE', 1400, 1399, 1400), true); // landing on target counts
  assert.equal(evaluate('CROSSES_BELOW', 1400, null, 1300), false);
  assert.equal(evaluate('CROSSES_BELOW', 1400, 1401, 1399), true);
  assert.equal(evaluate('CROSSES_BELOW', 1400, 1399, 1398), false);
  assert.equal(evaluate('CROSSES_BELOW', 1400, 1401, 1400), true);
});

test('float noise does not break exact matches', () => {
  assert.equal(evaluate('REACHES', 1400.1, null, 1400.1 + 1e-9), true);
  assert.equal(evaluate('ABOVE', 0.3, null, 0.1 + 0.2), false);
});
