import test from 'node:test';
import assert from 'node:assert/strict';
import { setup, FakeNotifier } from './helpers';
import { ProviderError } from '../src/market/provider';
import { TransientNotifyError, PermanentNotifyError } from '../src/alerts/notifier';

// ---------- basic conditions ----------

test('ABOVE fires and the message carries every required field', async () => {
  const s = setup();
  await s.create('u1', { condition: 'ABOVE', targetPrice: 1400 });
  const r = await s.tick(1405);
  assert.equal(r.triggered.length, 1);
  const body = s.notifiers.IN_APP.sent[0]!.body;
  for (const part of ['STOCK PRICE ALERT', 'Stock: RELIANCE', 'Exchange: NSE', 'Target Price: ₹1,400',
    'Observed Price: ₹1,405', 'Price rose above target', 'Time:']) {
    assert.ok(body.includes(part), `missing "${part}" in:\n${body}`);
  }
});

test('BELOW fires; no fire while price stays above', async () => {
  const s = setup();
  await s.create('u1', { condition: 'BELOW', targetPrice: 1400 });
  assert.equal((await s.tick(1450)).triggered.length, 0);
  const r = await s.tick(1398);
  assert.equal(r.triggered.length, 1);
  assert.ok(s.notifiers.IN_APP.sent[0]!.body.includes('Price fell below target'));
  assert.ok(s.notifiers.IN_APP.sent[0]!.body.includes('Observed Price: ₹1,398'));
});

test('CROSSES_ABOVE: first observation above target does not fire, a real crossing does', async () => {
  const s = setup();
  await s.create('u1', { condition: 'CROSSES_ABOVE', targetPrice: 1400 });
  assert.equal((await s.tick(1450)).triggered.length, 0); // already above, no crossing seen
  assert.equal((await s.tick(1460)).triggered.length, 0);
  const s2 = setup();
  await s2.create('u1', { condition: 'CROSSES_ABOVE', targetPrice: 1400 });
  await s2.tick(1390);
  assert.equal((await s2.tick(1410)).triggered.length, 1);
});

test('CROSSES_BELOW fires only on the transition', async () => {
  const s = setup();
  await s.create('u1', { condition: 'CROSSES_BELOW', targetPrice: 1400 });
  await s.tick(1410);
  assert.equal((await s.tick(1390)).triggered.length, 1);
});

test('exact target match fires REACHES; sitting on the target does not refire', async () => {
  const s = setup();
  await s.create('u1', { condition: 'REACHES', targetPrice: 1400, repeatEnabled: true });
  await s.tick(1390);
  assert.equal((await s.tick(1400)).triggered.length, 1);
  assert.equal((await s.tick(1400)).triggered.length, 0);
  assert.equal((await s.tick(1400)).triggered.length, 0);
});

// ---------- repeat behaviour ----------

test('one-shot alert fires once and switches itself off', async () => {
  const s = setup();
  const a = await s.create('u1', { condition: 'BELOW', targetPrice: 1400 });
  await s.tick(1390);
  await s.tick(1380);
  await s.tick(1370);
  assert.equal(s.notifiers.IN_APP.sent.length, 1);
  assert.equal((await s.alerts.get('u1', a.id)).isEnabled, false);
});

test('repeat alert: no spam while condition stays true, re-fires after leaving and re-entering', async () => {
  const s = setup();
  await s.create('u1', { condition: 'BELOW', targetPrice: 1400, repeatEnabled: true });
  await s.tick(1390); // fire #1
  await s.tick(1380); // still below: silent
  await s.tick(1370); // still below: silent
  assert.equal(s.notifiers.IN_APP.sent.length, 1);
  await s.tick(1410); // re-arm
  await s.tick(1395); // fire #2
  assert.equal(s.notifiers.IN_APP.sent.length, 2);
});

// ---------- data quality ----------

test('stale price never triggers', async () => {
  const s = setup();
  await s.create('u1', { condition: 'BELOW', targetPrice: 1400 });
  s.clock.advance(60_000);
  s.provider.setPrice('RELIANCE', 'NSE', 1300, new Date(s.clock.t.getTime() - 10 * 60_000)); // 10 min old
  const r = await s.engine.runCycle();
  assert.equal(r.triggered.length, 0);
  assert.equal(r.skipped[0]!.reason, 'STALE_DATA');
});

test('delayed feed is allowed its declared delay, but not more', async () => {
  const s = setup();
  const { MockMarketProvider } = await import('../src/market/mockProvider');
  const { AlertEngine } = await import('../src/alerts/engine');
  const delayed = new MockMarketProvider(s.clock.now, 'DELAYED', 900);
  delayed.addSymbol('RELIANCE', 'NSE');
  const eng = new AlertEngine({ store: s.store, provider: delayed, dispatcher: s.dispatcher, now: s.clock.now, workerId: 'w' });
  await s.create('u1', { condition: 'BELOW', targetPrice: 1400 });
  s.clock.advance(60_000);
  delayed.setPrice('RELIANCE', 'NSE', 1390, new Date(s.clock.t.getTime() - 15 * 60_000)); // 15 min = declared delay
  const r = await eng.runCycle();
  assert.equal(r.triggered.length, 1);
  assert.equal(s.notifiers.IN_APP.sent[0]!.event.dataMode, 'DELAYED');
  assert.ok(s.notifiers.IN_APP.sent[0]!.body.includes('Delayed'));
});

test('missing price and invalid symbol: no trigger, other alerts still processed', async () => {
  const s = setup();
  await s.create('u1', { symbol: 'TCS', condition: 'BELOW', targetPrice: 4000 });        // no price set
  await s.create('u1', { symbol: 'NOPE', condition: 'BELOW', targetPrice: 10 });        // unknown symbol
  await s.create('u1', { symbol: 'RELIANCE', condition: 'BELOW', targetPrice: 1400 });
  s.clock.advance(60_000);
  s.provider.setPrice('RELIANCE', 'NSE', 1390);
  const r = await s.engine.runCycle();
  assert.equal(r.triggered.length, 1);
  const reasons = r.skipped.map(x => x.reason).sort();
  assert.deepEqual(reasons, ['MISSING_DATA', 'PROVIDER_ERROR']);
  assert.equal(r.errors[0]!.code, 'INVALID_SYMBOL');
});

test('market holiday / closed / unknown: nothing is evaluated', async () => {
  for (const [state, reason] of [['HOLIDAY', 'MARKET_HOLIDAY'], ['CLOSED', 'MARKET_CLOSED'], ['UNKNOWN', 'MARKET_STATUS_UNKNOWN']] as const) {
    const s = setup();
    await s.create('u1', { condition: 'BELOW', targetPrice: 1400 });
    s.provider.setMarketStatus('NSE', { state, reason: 'Diwali (demo)' });
    const r = await s.tick(1300);
    assert.equal(r.triggered.length, 0);
    assert.equal(r.evaluated, 0);
    assert.equal(r.skipped[0]!.reason, reason);
    assert.equal(s.provider.calls, 0, 'should not even request quotes');
  }
});

test('expired alerts are not evaluated', async () => {
  const s = setup();
  await s.create('u1', { condition: 'BELOW', targetPrice: 1400, expiresAt: new Date(s.clock.t.getTime() + 90_000) });
  await s.tick(1410); // t+60s, still valid
  const r = await s.tick(1300); // t+120s, expired
  assert.equal(r.triggered.length, 0);
  assert.equal(r.evaluated, 0);
});

// ---------- rate limits ----------

test('rate limit: cycle survives, backs off without calling the provider, then resumes', async () => {
  const s = setup();
  await s.create('u1', { condition: 'BELOW', targetPrice: 1400 });
  s.clock.advance(60_000);
  s.provider.setPrice('RELIANCE', 'NSE', 1390);
  s.provider.queueError(new ProviderError('RATE_LIMITED', '429', 30_000));
  const r1 = await s.engine.runCycle();
  assert.equal(r1.triggered.length, 0);
  assert.equal(r1.skipped[0]!.reason, 'PROVIDER_RATE_LIMITED');
  assert.ok(r1.rateLimitedUntil);
  const callsAfterLimit = s.provider.calls;

  s.clock.advance(10_000); // still inside backoff
  const r2 = await s.engine.runCycle();
  assert.equal(r2.skippedCycle, 'RATE_LIMIT_BACKOFF');
  assert.equal(s.provider.calls, callsAfterLimit);

  s.clock.advance(25_000); // backoff over; quote is 35s old, still fresh
  const r3 = await s.engine.runCycle();
  assert.equal(r3.triggered.length, 1);
});

test('auth failure aborts the cycle and is reported', async () => {
  const s = setup();
  await s.create('u1', { condition: 'BELOW', targetPrice: 1400 });
  s.provider.queueError(new ProviderError('AUTH_FAILED', 'bad token'));
  const r = await s.tick(1300);
  assert.equal(r.errors[0]!.code, 'AUTH_FAILED');
  assert.equal(r.triggered.length, 0);
});

// ---------- duplicates / concurrency ----------

test('two workers running at once: lease lets only one in, one event, one notification', async () => {
  const s = setup();
  await s.create('u1', { condition: 'BELOW', targetPrice: 1400 });
  s.clock.advance(60_000);
  s.provider.setPrice('RELIANCE', 'NSE', 1390);
  const [a, b] = await Promise.all([s.mkEngine('w1').runCycle(), s.mkEngine('w2').runCycle()]);
  assert.equal(a.triggered.length + b.triggered.length, 1);
  assert.ok([a.skippedCycle, b.skippedCycle].includes('LEASE_HELD'));
  assert.equal(s.notifiers.IN_APP.sent.length, 1);
});

test('even with no lease, the dedup key stops a double trigger of the same quote', async () => {
  const s = setup();
  const alert = await s.create('u1', { condition: 'BELOW', targetPrice: 1400 });
  const ev = {
    id: 'e1', alertId: alert.id, userId: 'u1', symbol: 'RELIANCE', exchange: 'NSE' as const,
    condition: 'BELOW' as const, observedPrice: 1390, targetPrice: 1400, eventTimestamp: s.clock.now(),
    dataMode: 'REALTIME' as const, isDemo: true, provider: 'demo-mock',
    deduplicationKey: `${alert.id}:123`, deliveryStatus: 'PENDING' as const,
    deliveredChannels: [], attempts: {}, createdAt: s.clock.now(),
  };
  assert.equal(await s.store.commitTrigger(ev, {}), true);
  assert.equal(await s.store.commitTrigger({ ...ev, id: 'e2' }, {}), false);
  assert.equal((await s.store.listEventsByUser('u1')).length, 1);
});

test('re-running a cycle on an unchanged quote does nothing', async () => {
  const s = setup();
  await s.create('u1', { condition: 'BELOW', targetPrice: 1400, repeatEnabled: true });
  await s.tick(1390);
  s.clock.advance(1000);
  const r = await s.engine.runCycle(); // same quote timestamp
  assert.equal(r.skipped[0]!.reason, 'NO_NEW_DATA');
  assert.equal(s.notifiers.IN_APP.sent.length, 1);
});

// ---------- restart recovery ----------

test('restart: crossing detection survives because previous price is persisted', async () => {
  const s = setup();
  await s.create('u1', { condition: 'CROSSES_BELOW', targetPrice: 1400 });
  await s.tick(1410, 'RELIANCE', s.mkEngine('before-restart'));
  const r = await s.tick(1390, 'RELIANCE', s.mkEngine('after-restart')); // brand new engine instance
  assert.equal(r.triggered.length, 1);
});

test('restart: event saved but never delivered is delivered by the next worker, exactly once', async () => {
  const s = setup();
  const alert = await s.create('u1', { condition: 'BELOW', targetPrice: 1400 });
  // Simulate a crash right after the DB commit, before any notification went out.
  await s.store.commitTrigger({
    id: 'crashed', alertId: alert.id, userId: 'u1', symbol: 'RELIANCE', exchange: 'NSE',
    condition: 'BELOW', observedPrice: 1390, targetPrice: 1400, eventTimestamp: s.clock.now(),
    dataMode: 'REALTIME', isDemo: true, provider: 'demo-mock', deduplicationKey: `${alert.id}:1`,
    deliveryStatus: 'PENDING', deliveredChannels: [], attempts: {}, createdAt: s.clock.now(),
  }, { isEnabled: false, armed: false });
  const r = await s.mkEngine('new-worker').runCycle();
  assert.equal(r.redelivered, 1);
  assert.equal(s.notifiers.IN_APP.sent.length, 1);
  await s.mkEngine('another').runCycle();
  assert.equal(s.notifiers.IN_APP.sent.length, 1, 'must not resend');
  assert.equal((await s.store.listEventsByUser('u1'))[0]!.deliveryStatus, 'DELIVERED');
});

test('restart: a crashed worker\'s lease expires and another worker takes over', async () => {
  const s = setup();
  await s.create('u1', { condition: 'BELOW', targetPrice: 1400 });
  await s.store.acquireLease('alert-engine', 'dead-worker', 55_000, s.clock.now()); // never released
  s.clock.advance(10_000);
  s.provider.setPrice('RELIANCE', 'NSE', 1390);
  assert.equal((await s.mkEngine('w2').runCycle()).skippedCycle, 'LEASE_HELD');
  s.clock.advance(60_000);
  s.provider.setPrice('RELIANCE', 'NSE', 1385);
  assert.equal((await s.mkEngine('w2').runCycle()).triggered.length, 1);
});

// ---------- delivery retries ----------

test('transient channel failure is retried and delivered once', async () => {
  const s = setup();
  await s.store.setPrefs('u1', { browserPushEnabled: false, emailEnabled: true, soundEnabled: true });
  await s.create('u1', { condition: 'BELOW', targetPrice: 1400 });
  s.notifiers.EMAIL.failures.push(new TransientNotifyError('smtp 451'), new TransientNotifyError('smtp 451'));
  const r = await s.tick(1390);
  assert.equal(r.triggered.length, 1);
  assert.equal(s.notifiers.EMAIL.calls, 3);
  assert.equal(s.notifiers.EMAIL.sent.length, 1);
  const [ev] = await s.store.listEventsByUser('u1');
  assert.equal(ev!.deliveryStatus, 'DELIVERED');
  assert.equal((await s.store.listEventsByUser('u1')).length, 1, 'retries never create new events');
});

test('persistent failure -> PARTIAL; later cycle retries only the failed channel', async () => {
  const s = setup();
  await s.store.setPrefs('u1', { browserPushEnabled: false, emailEnabled: true, soundEnabled: true });
  await s.create('u1', { condition: 'BELOW', targetPrice: 1400 });
  for (let i = 0; i < 3; i++) s.notifiers.EMAIL.failures.push(new TransientNotifyError('down'));
  await s.tick(1390);
  let [ev] = await s.store.listEventsByUser('u1');
  assert.equal(ev!.deliveryStatus, 'PARTIAL');
  assert.deepEqual(ev!.deliveredChannels, ['IN_APP']);

  const r = await s.tick(1388); // next cycle: email recovered
  assert.equal(r.redelivered, 1);
  [ev] = await s.store.listEventsByUser('u1');
  assert.equal(ev!.deliveryStatus, 'DELIVERED');
  assert.equal(s.notifiers.IN_APP.sent.length, 1, 'in-app not resent');
  assert.equal(s.notifiers.EMAIL.sent.length, 1);
});

test('permanent failure is not retried forever', async () => {
  const s = setup();
  await s.store.setPrefs('u1', { browserPushEnabled: true, emailEnabled: false, soundEnabled: true });
  await s.create('u1', { condition: 'BELOW', targetPrice: 1400 });
  s.notifiers.BROWSER_PUSH.failures.push(new PermanentNotifyError('subscription expired'));
  await s.tick(1390);
  const calls = s.notifiers.BROWSER_PUSH.calls;
  await s.tick(1388);
  await s.tick(1386);
  assert.equal(s.notifiers.BROWSER_PUSH.calls, calls);
});

// ---------- multi-user / labeling ----------

test('two users, same stock: separate events, each respects its own preferences', async () => {
  const s = setup();
  await s.store.setPrefs('u2', { browserPushEnabled: false, emailEnabled: true, soundEnabled: false });
  await s.create('u1', { condition: 'BELOW', targetPrice: 1400 });
  await s.create('u2', { condition: 'BELOW', targetPrice: 1450 });
  await s.tick(1390);
  assert.equal((await s.store.listEventsByUser('u1')).length, 1);
  assert.equal((await s.store.listEventsByUser('u2')).length, 1);
  assert.equal(s.notifiers.EMAIL.sent.length, 1);
  assert.equal(s.notifiers.EMAIL.sent[0]!.userId, 'u2');
  assert.equal(s.provider.calls, 1, 'alerts are grouped: one quote request per symbol');
});

test('simulated prices are always labeled DEMO DATA', async () => {
  const s = setup();
  await s.create('u1', { condition: 'BELOW', targetPrice: 1400 });
  await s.tick(1390);
  assert.ok(s.notifiers.IN_APP.sent[0]!.body.includes('DEMO DATA'));
  assert.equal(s.notifiers.IN_APP.sent[0]!.event.isDemo, true);
});
