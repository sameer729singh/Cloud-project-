import { MockMarketProvider } from '../src/market/mockProvider';
import { InMemoryStore } from '../src/alerts/store';
import { AlertEngine } from '../src/alerts/engine';
import { AlertService, type CreateAlertInput } from '../src/alerts/service';
import { NotificationDispatcher, type Notifier, type NotificationPayload } from '../src/alerts/notifier';
import type { Channel } from '../src/types';

export class Clock {
  t = new Date('2026-10-22T05:00:00Z'); // 10:30 IST, a Thursday
  now = () => new Date(this.t);
  advance(ms: number) { this.t = new Date(this.t.getTime() + ms); }
}

export class FakeNotifier implements Notifier {
  sent: NotificationPayload[] = [];
  failures: Error[] = [];
  calls = 0;
  constructor(public channel: Channel) {}
  async send(p: NotificationPayload) {
    this.calls++;
    const f = this.failures.shift();
    if (f) throw f;
    this.sent.push(p);
  }
}

export function setup() {
  const clock = new Clock();
  const store = new InMemoryStore();
  const provider = new MockMarketProvider(clock.now);
  for (const s of ['RELIANCE', 'TCS', 'TATAMOTORS']) provider.addSymbol(s, 'NSE');
  const notifiers = {
    IN_APP: new FakeNotifier('IN_APP'),
    BROWSER_PUSH: new FakeNotifier('BROWSER_PUSH'),
    EMAIL: new FakeNotifier('EMAIL'),
  };
  const dispatcher = new NotificationDispatcher(store, Object.values(notifiers), { sleep: async () => {} });
  const mkEngine = (workerId = 'w1') =>
    new AlertEngine({ store, provider, dispatcher, now: clock.now, workerId });
  const engine = mkEngine();
  const alerts = new AlertService(store, clock.now);

  /** Advance 1 minute, publish a new price, run one cycle. */
  async function tick(price: number, symbol = 'RELIANCE', e = engine) {
    clock.advance(60_000);
    provider.setPrice(symbol, 'NSE', price);
    return e.runCycle();
  }
  const create = (userId: string, over: Partial<CreateAlertInput> = {}) =>
    alerts.create(userId, { symbol: 'RELIANCE', exchange: 'NSE', targetPrice: 1400, condition: 'BELOW', ...over });

  return { clock, store, provider, notifiers, dispatcher, mkEngine, engine, alerts, tick, create };
}
