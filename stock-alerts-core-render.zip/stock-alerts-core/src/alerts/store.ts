import type {
  Alert, AlertEvent, Exchange, NotificationPrefs, StockRef, Watchlist,
} from '../types';

/**
 * Persistence boundary. The engine and services only talk to this interface.
 * InMemoryStore below is for tests/demo; a Prisma/Postgres implementation must keep the
 * same guarantees (especially commitTrigger being one atomic transaction and
 * acquireLease being an atomic compare-and-set).
 */
export interface Store {
  // alerts
  createAlert(alert: Alert): Promise<Alert>;
  getAlert(id: string): Promise<Alert | undefined>;
  updateAlert(id: string, patch: Partial<Alert>): Promise<Alert | undefined>;
  deleteAlert(id: string): Promise<boolean>;
  listAlertsByUser(userId: string): Promise<Alert[]>;
  listActiveAlerts(now: Date): Promise<Alert[]>;
  // events
  /** Atomically: insert event + patch alert. Returns false (and changes nothing) if the dedup key exists. */
  commitTrigger(event: AlertEvent, alertPatch: Partial<Alert>): Promise<boolean>;
  updateEvent(id: string, patch: Partial<AlertEvent>): Promise<void>;
  listEventsNotDelivered(): Promise<AlertEvent[]>;
  listEventsByUser(userId: string): Promise<AlertEvent[]>;
  // prefs
  getPrefs(userId: string): Promise<NotificationPrefs>;
  setPrefs(userId: string, prefs: NotificationPrefs): Promise<void>;
  // worker lease (one active engine at a time)
  acquireLease(name: string, owner: string, ttlMs: number, now: Date): Promise<boolean>;
  releaseLease(name: string, owner: string): Promise<void>;
  // watchlists
  createWatchlist(w: Watchlist): Promise<Watchlist>;
  getWatchlist(id: string): Promise<Watchlist | undefined>;
  listWatchlists(userId: string): Promise<Watchlist[]>;
  updateWatchlist(id: string, patch: Partial<Watchlist>): Promise<Watchlist | undefined>;
  deleteWatchlist(id: string): Promise<boolean>;
}

const copy = <T>(v: T): T => structuredClone(v);

export class InMemoryStore implements Store {
  private alerts = new Map<string, Alert>();
  private events = new Map<string, AlertEvent>();
  private dedup = new Set<string>();
  private prefs = new Map<string, NotificationPrefs>();
  private leases = new Map<string, { owner: string; expiresAt: Date }>();
  private watchlists = new Map<string, Watchlist>();

  async createAlert(alert: Alert) { this.alerts.set(alert.id, copy(alert)); return copy(alert); }
  async getAlert(id: string) { const a = this.alerts.get(id); return a ? copy(a) : undefined; }
  async updateAlert(id: string, patch: Partial<Alert>) {
    const a = this.alerts.get(id);
    if (!a) return undefined;
    Object.assign(a, copy(patch));
    return copy(a);
  }
  async deleteAlert(id: string) { return this.alerts.delete(id); }
  async listAlertsByUser(userId: string) {
    return [...this.alerts.values()].filter(a => a.userId === userId).map(copy);
  }
  async listActiveAlerts(now: Date) {
    return [...this.alerts.values()]
      .filter(a => a.isEnabled && (!a.expiresAt || a.expiresAt.getTime() > now.getTime()))
      .map(copy);
  }

  async commitTrigger(event: AlertEvent, alertPatch: Partial<Alert>) {
    if (this.dedup.has(event.deduplicationKey)) return false;
    const alert = this.alerts.get(event.alertId);
    if (!alert) return false;
    // Single synchronous block = atomic here. In Postgres: one transaction with a unique index.
    this.dedup.add(event.deduplicationKey);
    this.events.set(event.id, copy(event));
    Object.assign(alert, copy(alertPatch));
    return true;
  }
  async updateEvent(id: string, patch: Partial<AlertEvent>) {
    const e = this.events.get(id);
    if (e) Object.assign(e, copy(patch));
  }
  async listEventsNotDelivered() {
    return [...this.events.values()].filter(e => e.deliveryStatus !== 'DELIVERED').map(copy);
  }
  async listEventsByUser(userId: string) {
    return [...this.events.values()].filter(e => e.userId === userId).map(copy);
  }

  async getPrefs(userId: string) {
    return copy(this.prefs.get(userId) ?? { browserPushEnabled: false, emailEnabled: false, soundEnabled: true });
  }
  async setPrefs(userId: string, prefs: NotificationPrefs) { this.prefs.set(userId, copy(prefs)); }

  async acquireLease(name: string, owner: string, ttlMs: number, now: Date) {
    const cur = this.leases.get(name);
    if (cur && cur.owner !== owner && cur.expiresAt.getTime() > now.getTime()) return false;
    this.leases.set(name, { owner, expiresAt: new Date(now.getTime() + ttlMs) });
    return true;
  }
  async releaseLease(name: string, owner: string) {
    if (this.leases.get(name)?.owner === owner) this.leases.delete(name);
  }

  async createWatchlist(w: Watchlist) { this.watchlists.set(w.id, copy(w)); return copy(w); }
  async getWatchlist(id: string) { const w = this.watchlists.get(id); return w ? copy(w) : undefined; }
  async listWatchlists(userId: string) {
    return [...this.watchlists.values()].filter(w => w.userId === userId).map(copy);
  }
  async updateWatchlist(id: string, patch: Partial<Watchlist>) {
    const w = this.watchlists.get(id);
    if (!w) return undefined;
    Object.assign(w, copy(patch));
    return copy(w);
  }
  async deleteWatchlist(id: string) { return this.watchlists.delete(id); }
}

export type { Exchange, StockRef };
