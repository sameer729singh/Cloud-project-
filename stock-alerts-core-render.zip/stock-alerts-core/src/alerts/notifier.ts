import type { AlertCondition, AlertEvent, Channel, DeliveryStatus } from '../types';
import type { Store } from './store';

export interface NotificationPayload {
  eventId: string;
  userId: string;
  title: 'STOCK PRICE ALERT';
  body: string;
  event: AlertEvent;
}

export interface Notifier {
  readonly channel: Channel;
  send(payload: NotificationPayload): Promise<void>;
}

/** Retrying may help (network blip, 5xx). */
export class TransientNotifyError extends Error {}
/** Retrying will not help (bad address, revoked push subscription). */
export class PermanentNotifyError extends Error {}

const inr = (n: number) => `₹${n.toLocaleString('en-IN', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;

const CONDITION_TEXT: Record<AlertCondition, string> = {
  ABOVE: 'Price rose above target',
  BELOW: 'Price fell below target',
  REACHES: 'Price reached target',
  CROSSES_ABOVE: 'Price crossed above target',
  CROSSES_BELOW: 'Price crossed below target',
};

const MODE_TEXT = { REALTIME: 'Real-time', DELAYED: 'Delayed', EOD: 'End-of-day' } as const;

export function formatAlertMessage(e: AlertEvent): string {
  const when = e.eventTimestamp.toLocaleString('en-IN', {
    timeZone: 'Asia/Kolkata', dateStyle: 'medium', timeStyle: 'medium',
  });
  const lines = [
    'STOCK PRICE ALERT',
    `Stock: ${e.symbol}`,
    `Exchange: ${e.exchange}`,
    `Target Price: ${inr(e.targetPrice)}`,
    `Observed Price: ${inr(e.observedPrice)}`,
    `Condition: ${CONDITION_TEXT[e.condition]}`,
    `Time: ${when} IST`,
    `Data: ${MODE_TEXT[e.dataMode]} (${e.provider})`,
  ];
  if (e.isDemo) lines.push('DEMO DATA: simulated price, not a live market quote');
  return lines.join('\n');
}

/**
 * The AlertEvent row itself is the in-app notification (it feeds the history page and toasts),
 * so this channel has nothing to send. Kept as a Notifier so every channel is handled uniformly.
 */
export class InAppNotifier implements Notifier {
  readonly channel = 'IN_APP' as const;
  async send(): Promise<void> {}
}

export interface DispatcherOptions {
  /** Tries per channel within one deliver() call. */
  attemptsPerRun?: number;
  /** Lifetime cap per channel, across restarts and retries. */
  maxTotalAttempts?: number;
  backoffMs?: number;
  sleep?: (ms: number) => Promise<void>;
}

export class NotificationDispatcher {
  private o: Required<DispatcherOptions>;

  constructor(private store: Store, private notifiers: Notifier[], opts: DispatcherOptions = {}) {
    this.o = {
      attemptsPerRun: opts.attemptsPerRun ?? 3,
      maxTotalAttempts: opts.maxTotalAttempts ?? 6,
      backoffMs: opts.backoffMs ?? 500,
      sleep: opts.sleep ?? ((ms) => new Promise(r => setTimeout(r, ms))),
    };
  }

  /** Idempotent per channel: channels already delivered are never sent again. */
  async deliver(event: AlertEvent): Promise<AlertEvent> {
    const prefs = await this.store.getPrefs(event.userId);
    const wanted: Channel[] = ['IN_APP'];
    if (prefs.browserPushEnabled) wanted.push('BROWSER_PUSH');
    if (prefs.emailEnabled) wanted.push('EMAIL');

    const delivered = new Set(event.deliveredChannels);
    const attempts = { ...event.attempts };
    const payload: NotificationPayload = {
      eventId: event.id, userId: event.userId, title: 'STOCK PRICE ALERT',
      body: formatAlertMessage(event), event,
    };

    const active: Channel[] = [];
    for (const ch of wanted) {
      const notifier = this.notifiers.find(n => n.channel === ch);
      if (!notifier) continue; // channel not configured on this server
      active.push(ch);
      if (delivered.has(ch)) continue;
      for (let i = 0; i < this.o.attemptsPerRun; i++) {
        if ((attempts[ch] ?? 0) >= this.o.maxTotalAttempts) break;
        attempts[ch] = (attempts[ch] ?? 0) + 1;
        try {
          await notifier.send(payload);
          delivered.add(ch);
          break;
        } catch (e) {
          if (e instanceof PermanentNotifyError) { attempts[ch] = this.o.maxTotalAttempts; break; }
          if (i < this.o.attemptsPerRun - 1) await this.o.sleep(this.o.backoffMs * 2 ** i);
        }
      }
    }

    const pending = active.filter(ch => !delivered.has(ch));
    const status: DeliveryStatus =
      pending.length === 0 ? 'DELIVERED' : delivered.size > 0 ? 'PARTIAL' : 'FAILED';
    const patch = { deliveredChannels: [...delivered], attempts, deliveryStatus: status };
    await this.store.updateEvent(event.id, patch);
    return { ...event, ...patch };
  }

  /** Re-attempts events that are not fully delivered (e.g. crash after commit). Returns how many were attempted. */
  async retryPending(): Promise<number> {
    let n = 0;
    for (const e of await this.store.listEventsNotDelivered()) {
      const before = sum(e.attempts);
      const after = await this.deliver(e);
      if (sum(after.attempts) > before) n++;
    }
    return n;
  }
}

const sum = (a: Partial<Record<Channel, number>>) => Object.values(a).reduce((x, y) => x + (y ?? 0), 0);
