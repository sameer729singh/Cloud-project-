import { randomUUID } from 'node:crypto';
import { CONDITIONS, EXCHANGES, type Alert, type AlertCondition, type Exchange } from '../types';
import type { Store } from './store';

export class NotFoundError extends Error {}
export class ValidationError extends Error {
  constructor(public issues: string[]) { super(issues.join('; ')); }
}
export class LimitError extends Error {}

export const MAX_ALERTS_PER_USER = 200;
const SYMBOL_RE = /^[A-Z0-9&-]{1,20}$/;

export interface CreateAlertInput {
  symbol: string;
  exchange: Exchange;
  targetPrice: number;
  condition: AlertCondition;
  repeatEnabled?: boolean;
  expiresAt?: Date | null;
}
export type UpdateAlertInput = Partial<Pick<CreateAlertInput, 'targetPrice' | 'condition' | 'repeatEnabled' | 'expiresAt'>> & {
  isEnabled?: boolean;
};

function check(input: Partial<CreateAlertInput> & { isEnabled?: boolean }, now: Date, partial: boolean): string[] {
  const issues: string[] = [];
  const has = (k: keyof typeof input) => input[k] !== undefined;
  if (!partial || has('symbol')) {
    if (typeof input.symbol !== 'string' || !SYMBOL_RE.test(input.symbol)) issues.push('symbol must be 1-20 chars of A-Z, 0-9, & or -');
  }
  if (!partial || has('exchange')) {
    if (!EXCHANGES.includes(input.exchange as Exchange)) issues.push('exchange must be NSE or BSE');
  }
  if (!partial || has('targetPrice')) {
    const p = input.targetPrice;
    if (typeof p !== 'number' || !Number.isFinite(p) || p <= 0 || p > 10_000_000) issues.push('targetPrice must be a positive number up to 10,000,000');
  }
  if (!partial || has('condition')) {
    if (!CONDITIONS.includes(input.condition as AlertCondition)) issues.push('condition is not supported');
  }
  if (has('expiresAt') && input.expiresAt !== null) {
    if (!(input.expiresAt instanceof Date) || Number.isNaN(input.expiresAt.getTime()) || input.expiresAt.getTime() <= now.getTime()) {
      issues.push('expiresAt must be a future date');
    }
  }
  return issues;
}

/**
 * Every method takes the caller's userId and enforces ownership.
 * A foreign alert id gives the same NotFoundError as a missing one, so ids can't be probed.
 */
export class AlertService {
  constructor(private store: Store, private now: () => Date = () => new Date()) {}

  async create(userId: string, input: CreateAlertInput): Promise<Alert> {
    const now = this.now();
    const issues = check(input, now, false);
    if (issues.length) throw new ValidationError(issues);
    if ((await this.store.listAlertsByUser(userId)).length >= MAX_ALERTS_PER_USER) {
      throw new LimitError(`Alert limit of ${MAX_ALERTS_PER_USER} reached`);
    }
    return this.store.createAlert({
      id: randomUUID(), userId,
      symbol: input.symbol, exchange: input.exchange,
      targetPrice: input.targetPrice, condition: input.condition,
      isEnabled: true, repeatEnabled: input.repeatEnabled ?? false,
      expiresAt: input.expiresAt ?? null,
      lastTriggeredAt: null, lastObservedPrice: null, lastQuoteTimestamp: null, armed: true,
      createdAt: now, updatedAt: now,
    });
  }

  list(userId: string) { return this.store.listAlertsByUser(userId); }

  async get(userId: string, id: string): Promise<Alert> {
    const a = await this.store.getAlert(id);
    if (!a || a.userId !== userId) throw new NotFoundError('Alert not found');
    return a;
  }

  async update(userId: string, id: string, input: UpdateAlertInput): Promise<Alert> {
    const current = await this.get(userId, id);
    const now = this.now();
    const issues = check(input, now, true);
    if (issues.length) throw new ValidationError(issues);

    // Explicit allow-list: id/userId/engine state can never be set by the caller.
    const patch: Partial<Alert> = { updatedAt: now };
    if (input.targetPrice !== undefined) patch.targetPrice = input.targetPrice;
    if (input.condition !== undefined) patch.condition = input.condition;
    if (input.repeatEnabled !== undefined) patch.repeatEnabled = input.repeatEnabled;
    if (input.expiresAt !== undefined) patch.expiresAt = input.expiresAt;
    if (input.isEnabled !== undefined) patch.isEnabled = input.isEnabled;

    const changedRule = (patch.targetPrice !== undefined && patch.targetPrice !== current.targetPrice)
      || (patch.condition !== undefined && patch.condition !== current.condition);
    const resumed = input.isEnabled === true && !current.isEnabled;
    if (changedRule) patch.armed = true;
    if (resumed) {
      // The old "previous price" may be hours old; using it could fake a crossing.
      patch.armed = true; patch.lastObservedPrice = null; patch.lastQuoteTimestamp = null;
    }
    return (await this.store.updateAlert(id, patch))!;
  }

  async delete(userId: string, id: string): Promise<void> {
    await this.get(userId, id);
    await this.store.deleteAlert(id);
  }
}
