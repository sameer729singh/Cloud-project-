import { randomUUID } from 'node:crypto';
import type { Alert, AlertEvent, Exchange, MarketStatus, Quote } from '../types';
import { classifyFreshness, ProviderError, type MarketDataProvider } from '../market/provider';
import { evaluate } from './evaluate';
import type { NotificationDispatcher } from './notifier';
import type { Store } from './store';

export type SkipReason =
  | 'MARKET_CLOSED' | 'MARKET_HOLIDAY' | 'MARKET_STATUS_UNKNOWN'
  | 'MISSING_DATA' | 'STALE_DATA' | 'EOD_DATA' | 'NO_NEW_DATA'
  | 'PROVIDER_ERROR' | 'PROVIDER_RATE_LIMITED' | 'PROVIDER_AUTH_FAILED';

export interface CycleReport {
  startedAt: Date;
  skippedCycle?: 'LEASE_HELD' | 'RATE_LIMIT_BACKOFF';
  evaluated: number;
  triggered: string[];
  skipped: { alertId: string; reason: SkipReason }[];
  errors: { key: string; code: string; message: string }[];
  redelivered: number;
  rateLimitedUntil?: Date;
}

export interface EngineConfig {
  /** Max age of a real-time quote before it is considered stale. */
  staleAfterMs: number;
  leaseTtlMs: number;
  defaultBackoffMs: number;
}

export interface EngineDeps {
  store: Store;
  provider: MarketDataProvider;
  dispatcher: NotificationDispatcher;
  now: () => Date;
  workerId: string;
  config?: Partial<EngineConfig>;
}

const LEASE = 'alert-engine';

export class AlertEngine {
  private cfg: EngineConfig;
  private backoffUntil: Date | null = null;

  constructor(private d: EngineDeps) {
    this.cfg = { staleAfterMs: 120_000, leaseTtlMs: 55_000, defaultBackoffMs: 60_000, ...d.config };
  }

  /** One monitoring pass. Call it from a scheduler (e.g. every minute). Safe to call from several workers. */
  async runCycle(): Promise<CycleReport> {
    const { store, provider, dispatcher } = this.d;
    const now = this.d.now();
    const report: CycleReport = {
      startedAt: now, evaluated: 0, triggered: [], skipped: [], errors: [], redelivered: 0,
    };

    if (!(await store.acquireLease(LEASE, this.d.workerId, this.cfg.leaseTtlMs, now))) {
      report.skippedCycle = 'LEASE_HELD';
      return report;
    }
    try {
      // Recovery: events saved but not (fully) delivered, e.g. the process died after commit.
      report.redelivered = await dispatcher.retryPending();

      if (this.backoffUntil && now < this.backoffUntil) {
        report.skippedCycle = 'RATE_LIMIT_BACKOFF';
        report.rateLimitedUntil = this.backoffUntil;
        return report;
      }
      this.backoffUntil = null;

      const groups = new Map<string, Alert[]>();
      for (const a of await store.listActiveAlerts(now)) {
        const key = `${a.exchange}:${a.symbol}`;
        (groups.get(key) ?? groups.set(key, []).get(key)!).push(a);
      }

      const statusCache = new Map<Exchange, MarketStatus>();
      let abort: SkipReason | null = null;
      const skipAll = (alerts: Alert[], reason: SkipReason) => {
        for (const a of alerts) report.skipped.push({ alertId: a.id, reason });
      };

      for (const [key, alerts] of groups) {
        if (abort) { skipAll(alerts, abort); continue; }
        const [exchange, symbol] = key.split(':') as [Exchange, string];

        let status = statusCache.get(exchange);
        if (!status) {
          try { status = await provider.getMarketStatus(exchange); }
          catch { status = { state: 'UNKNOWN' }; }
          statusCache.set(exchange, status);
        }
        if (status.state !== 'OPEN') {
          skipAll(alerts, status.state === 'HOLIDAY' ? 'MARKET_HOLIDAY'
            : status.state === 'CLOSED' ? 'MARKET_CLOSED' : 'MARKET_STATUS_UNKNOWN');
          continue;
        }

        let quote: Quote | null;
        try {
          quote = await provider.getQuote(symbol, exchange);
        } catch (e) {
          const code = e instanceof ProviderError ? e.code : 'UNKNOWN';
          report.errors.push({ key, code, message: (e as Error).message });
          if (code === 'RATE_LIMITED') {
            const wait = (e as ProviderError).retryAfterMs ?? this.cfg.defaultBackoffMs;
            this.backoffUntil = new Date(now.getTime() + wait);
            report.rateLimitedUntil = this.backoffUntil;
            abort = 'PROVIDER_RATE_LIMITED';
            skipAll(alerts, abort);
          } else if (code === 'AUTH_FAILED') {
            abort = 'PROVIDER_AUTH_FAILED';
            skipAll(alerts, abort);
          } else {
            skipAll(alerts, 'PROVIDER_ERROR');
          }
          continue;
        }

        const freshness = classifyFreshness(quote, now, this.cfg.staleAfterMs);
        if (freshness === 'MISSING') { skipAll(alerts, 'MISSING_DATA'); continue; }
        if (freshness === 'STALE') { skipAll(alerts, 'STALE_DATA'); continue; }
        if (freshness === 'EOD') { skipAll(alerts, 'EOD_DATA'); continue; }

        for (const alert of alerts) await this.processAlert(alert, quote!, now, report);
      }
      return report;
    } finally {
      await store.releaseLease(LEASE, this.d.workerId);
    }
  }

  private async processAlert(alert: Alert, quote: Quote, now: Date, report: CycleReport) {
    const { store, dispatcher } = this.d;
    if (alert.lastQuoteTimestamp && quote.marketTimestamp.getTime() <= alert.lastQuoteTimestamp.getTime()) {
      report.skipped.push({ alertId: alert.id, reason: 'NO_NEW_DATA' });
      return;
    }
    report.evaluated++;
    const met = evaluate(alert.condition, alert.targetPrice, alert.lastObservedPrice, quote.price);
    const observed = {
      lastObservedPrice: quote.price, lastQuoteTimestamp: quote.marketTimestamp, updatedAt: now,
    };

    if (met && alert.armed) {
      const event: AlertEvent = {
        id: randomUUID(), alertId: alert.id, userId: alert.userId,
        symbol: alert.symbol, exchange: alert.exchange, condition: alert.condition,
        observedPrice: quote.price, targetPrice: alert.targetPrice,
        eventTimestamp: quote.marketTimestamp, dataMode: quote.dataMode,
        isDemo: quote.isDemo, provider: quote.provider,
        deduplicationKey: `${alert.id}:${quote.marketTimestamp.getTime()}`,
        deliveryStatus: 'PENDING', deliveredChannels: [], attempts: {}, createdAt: now,
      };
      const committed = await store.commitTrigger(event, {
        ...observed, armed: false, lastTriggeredAt: now,
        isEnabled: alert.repeatEnabled, // one-shot alerts switch themselves off
      });
      if (!committed) return; // another worker already recorded this exact trigger
      report.triggered.push(event.id);
      try { await dispatcher.deliver(event); }
      catch (e) { report.errors.push({ key: event.id, code: 'DELIVERY', message: (e as Error).message }); }
      return;
    }
    // Condition false -> re-arm. Condition still true after firing -> stay disarmed (no repeats).
    await store.updateAlert(alert.id, { ...observed, armed: met ? alert.armed : true });
  }
}
