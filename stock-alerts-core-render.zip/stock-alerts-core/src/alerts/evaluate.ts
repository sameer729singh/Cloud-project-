import type { AlertCondition } from '../types';

// Compare in integer paise so 1400.10 vs 1400.1 and float noise never matter.
const paise = (n: number) => Math.round(n * 100);

/**
 * Pure condition check.
 *  ABOVE / BELOW      strict level comparison.
 *  REACHES            price equals target, or jumped across it since the previous observation.
 *  CROSSES_ABOVE      previous < target and now >= target (landing exactly on target counts).
 *  CROSSES_BELOW      previous > target and now <= target.
 * Crossing conditions need a previous price; with none they are false.
 */
export function evaluate(
  condition: AlertCondition, target: number, previous: number | null, current: number,
): boolean {
  const t = paise(target);
  const c = paise(current);
  const p = previous === null ? null : paise(previous);
  switch (condition) {
    case 'ABOVE': return c > t;
    case 'BELOW': return c < t;
    case 'REACHES': return c === t || (p !== null && ((p < t && c > t) || (p > t && c < t)));
    case 'CROSSES_ABOVE': return p !== null && p < t && c >= t;
    case 'CROSSES_BELOW': return p !== null && p > t && c <= t;
  }
}
