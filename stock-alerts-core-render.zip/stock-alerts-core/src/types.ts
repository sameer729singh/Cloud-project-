export type Exchange = 'NSE' | 'BSE';
export const EXCHANGES: readonly Exchange[] = ['NSE', 'BSE'];

export type AlertCondition = 'ABOVE' | 'BELOW' | 'REACHES' | 'CROSSES_ABOVE' | 'CROSSES_BELOW';
export const CONDITIONS: readonly AlertCondition[] = [
  'ABOVE', 'BELOW', 'REACHES', 'CROSSES_ABOVE', 'CROSSES_BELOW',
];

/** How the provider says the price was produced. */
export type DataMode = 'REALTIME' | 'DELAYED' | 'EOD';
/** DataMode plus the engine's own verdicts. */
export type Freshness = DataMode | 'STALE' | 'MISSING';

export type Channel = 'IN_APP' | 'BROWSER_PUSH' | 'EMAIL';
export type DeliveryStatus = 'PENDING' | 'DELIVERED' | 'PARTIAL' | 'FAILED';

export interface StockRef { symbol: string; exchange: Exchange }

export interface MarketStatus {
  state: 'OPEN' | 'CLOSED' | 'HOLIDAY' | 'UNKNOWN';
  reason?: string;
}

export interface Quote {
  symbol: string;
  exchange: Exchange;
  price: number;
  currency: 'INR';
  marketTimestamp: Date;
  retrievedAt: Date;
  dataMode: DataMode;
  delaySeconds?: number | undefined;
  provider: string;
  /** True for simulated prices. Must always be shown as DEMO DATA. */
  isDemo: boolean;
}

export interface Alert {
  id: string;
  userId: string;
  symbol: string;
  exchange: Exchange;
  targetPrice: number;
  condition: AlertCondition;
  isEnabled: boolean;
  repeatEnabled: boolean;
  expiresAt: Date | null;
  lastTriggeredAt: Date | null;
  /** Previous observed price, needed for crossing logic. Persisted so restarts don't lose it. */
  lastObservedPrice: number | null;
  /** Market timestamp of the last quote this alert was evaluated against. */
  lastQuoteTimestamp: Date | null;
  /** False after firing until the condition becomes false again. Prevents repeat notifications. */
  armed: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface AlertEvent {
  id: string;
  alertId: string;
  userId: string;
  symbol: string;
  exchange: Exchange;
  condition: AlertCondition;
  observedPrice: number;
  targetPrice: number;
  /** Market timestamp of the triggering quote (the real event time). */
  eventTimestamp: Date;
  dataMode: DataMode;
  isDemo: boolean;
  provider: string;
  deduplicationKey: string;
  deliveryStatus: DeliveryStatus;
  deliveredChannels: Channel[];
  attempts: Partial<Record<Channel, number>>;
  createdAt: Date;
}

export interface NotificationPrefs {
  browserPushEnabled: boolean;
  emailEnabled: boolean;
  soundEnabled: boolean;
}

export interface Watchlist {
  id: string;
  userId: string;
  name: string;
  stocks: StockRef[];
  createdAt: Date;
}
