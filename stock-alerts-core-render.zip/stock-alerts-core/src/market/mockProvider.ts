import type { DataMode, Exchange, MarketStatus, Quote } from '../types';
import { EXCHANGES } from '../types';
import { ProviderError, type MarketDataProvider } from './provider';

/**
 * DEMO provider for development and tests. Every quote it returns has isDemo=true.
 * Prices are whatever the caller sets; nothing here resembles live market data.
 */
export class MockMarketProvider implements MarketDataProvider {
  readonly id = 'demo-mock';
  calls = 0;
  private prices = new Map<string, { price: number; ts: Date } | null>();
  private status = new Map<Exchange, MarketStatus>();
  private errors: Error[] = [];

  constructor(
    private now: () => Date,
    private mode: DataMode = 'REALTIME',
    private delaySeconds = 0,
  ) {}

  private k(symbol: string, exchange: Exchange) { return `${exchange}:${symbol}`; }

  /** Registers a symbol with no price yet (getQuote returns null). */
  addSymbol(symbol: string, exchange: Exchange) { this.prices.set(this.k(symbol, exchange), null); }

  setPrice(symbol: string, exchange: Exchange, price: number, marketTimestamp: Date = this.now()) {
    this.prices.set(this.k(symbol, exchange), { price, ts: marketTimestamp });
  }

  setMarketStatus(exchange: Exchange, status: MarketStatus) { this.status.set(exchange, status); }

  /** The next provider call throws this error. */
  queueError(e: Error) { this.errors.push(e); }

  async getQuote(symbol: string, exchange: Exchange): Promise<Quote | null> {
    this.calls++;
    const err = this.errors.shift();
    if (err) throw err;
    if (!EXCHANGES.includes(exchange)) throw new ProviderError('UNSUPPORTED_EXCHANGE', `Unsupported exchange ${exchange}`);
    const key = this.k(symbol, exchange);
    if (!this.prices.has(key)) throw new ProviderError('INVALID_SYMBOL', `Unknown symbol ${key}`);
    const p = this.prices.get(key);
    if (!p) return null;
    return {
      symbol, exchange, price: p.price, currency: 'INR',
      marketTimestamp: p.ts, retrievedAt: this.now(),
      dataMode: this.mode, delaySeconds: this.delaySeconds || undefined,
      provider: this.id, isDemo: true,
    };
  }

  async getMarketStatus(exchange: Exchange): Promise<MarketStatus> {
    return this.status.get(exchange) ?? { state: 'OPEN' };
  }
}
