import type { Exchange, Freshness, MarketStatus, Quote } from '../types';

export type ProviderErrorCode =
  | 'RATE_LIMITED' | 'AUTH_FAILED' | 'INVALID_SYMBOL'
  | 'UNSUPPORTED_EXCHANGE' | 'OUTAGE' | 'NETWORK';

export class ProviderError extends Error {
  constructor(public code: ProviderErrorCode, message: string, public retryAfterMs?: number) {
    super(message);
    this.name = 'ProviderError';
  }
}

/** Every market-data integration (Upstox, Kite, SmartAPI, ...) implements this. */
export interface MarketDataProvider {
  readonly id: string;
  /** null = known symbol but no price available right now. Throws ProviderError on failures. */
  getQuote(symbol: string, exchange: Exchange): Promise<Quote | null>;
  getMarketStatus(exchange: Exchange): Promise<MarketStatus>;
}

const CLOCK_SKEW_MS = 60_000;

/**
 * Decides whether a quote may be used to trigger alerts.
 * Delayed feeds get their declared delay added to the allowed age.
 */
export function classifyFreshness(quote: Quote | null, now: Date, staleAfterMs: number): Freshness {
  if (!quote || !Number.isFinite(quote.price) || quote.price <= 0) return 'MISSING';
  if (quote.dataMode === 'EOD') return 'EOD';
  const age = now.getTime() - quote.marketTimestamp.getTime();
  if (age < -CLOCK_SKEW_MS) return 'STALE'; // timestamp from the future: untrustworthy
  if (age > staleAfterMs + (quote.delaySeconds ?? 0) * 1000) return 'STALE';
  return quote.dataMode;
}
