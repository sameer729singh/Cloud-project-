import { randomUUID } from 'node:crypto';
import { EXCHANGES, type Exchange, type Watchlist } from './types';
import { NotFoundError, ValidationError } from './alerts/service';
import type { Store } from './alerts/store';

export class WatchlistService {
  constructor(private store: Store, private now: () => Date = () => new Date()) {}

  async create(userId: string, name: string): Promise<Watchlist> {
    const n = typeof name === 'string' ? name.trim() : '';
    if (n.length < 1 || n.length > 60) throw new ValidationError(['name must be 1-60 characters']);
    return this.store.createWatchlist({ id: randomUUID(), userId, name: n, stocks: [], createdAt: this.now() });
  }

  list(userId: string) { return this.store.listWatchlists(userId); }

  private async owned(userId: string, id: string): Promise<Watchlist> {
    const w = await this.store.getWatchlist(id);
    if (!w || w.userId !== userId) throw new NotFoundError('Watchlist not found');
    return w;
  }

  async addStock(userId: string, id: string, symbol: string, exchange: Exchange): Promise<Watchlist> {
    const w = await this.owned(userId, id);
    if (!/^[A-Z0-9&-]{1,20}$/.test(symbol) || !EXCHANGES.includes(exchange)) {
      throw new ValidationError(['invalid symbol or exchange']);
    }
    if (w.stocks.some(s => s.symbol === symbol && s.exchange === exchange)) return w;
    return (await this.store.updateWatchlist(id, { stocks: [...w.stocks, { symbol, exchange }] }))!;
  }

  async removeStock(userId: string, id: string, symbol: string, exchange: Exchange): Promise<Watchlist> {
    const w = await this.owned(userId, id);
    return (await this.store.updateWatchlist(id, {
      stocks: w.stocks.filter(s => !(s.symbol === symbol && s.exchange === exchange)),
    }))!;
  }

  async delete(userId: string, id: string): Promise<void> {
    await this.owned(userId, id);
    await this.store.deleteWatchlist(id);
  }
}
