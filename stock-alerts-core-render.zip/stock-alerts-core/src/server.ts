import { createServer } from 'node:http';

const port = Number(process.env.PORT ?? 10000);
const host = '0.0.0.0';

const server = createServer((req, res) => {
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  const path = new URL(req.url ?? '/', `http://${req.headers.host ?? 'localhost'}`).pathname;

  if (req.method === 'GET' && (path === '/' || path === '/health')) {
    res.writeHead(200);
    res.end(JSON.stringify({
      status: 'ok',
      service: 'stock-alerts-core',
      timestamp: new Date().toISOString(),
      mode: 'core-only',
      marketData: 'not-connected',
      message: 'Service is running. No live stock prices or authenticated alert API is configured yet.'
    }));
    return;
  }

  if (req.method === 'GET' && path === '/api/info') {
    res.writeHead(200);
    res.end(JSON.stringify({
      name: 'Stock Alerts Core API',
      version: '0.1.0',
      available: ['GET /health', 'GET /api/info'],
      notImplemented: ['live market quotes', 'alert CRUD endpoints', 'authentication', 'persistent database', 'notifications'],
      warning: 'This deployment does not provide live NSE/BSE prices. Do not use it for trading decisions.'
    }));
    return;
  }

  res.writeHead(404);
  res.end(JSON.stringify({ error: 'Not found', available: ['GET /health', 'GET /api/info'] }));
});

server.listen(port, host, () => {
  console.log(`Stock Alerts Core listening on ${host}:${port}`);
});
